package no.oslomet.amazon.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import no.oslomet.amazon.model.Order;
import no.oslomet.amazon.model.Shipping;
import no.oslomet.amazon.service.OrderService;
import no.oslomet.amazon.service.ShippingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

@org.springframework.web.bind.annotation.RestController
@CrossOrigin
public class RestController {


    @Autowired
    OrderService orderService;
    @Autowired
    ShippingService shippingService;


    @GetMapping("/")
    public String home(){
        return "This is the user rest controller";
    }


    /* ==================================== Order ==================================== */

    @GetMapping("/orders")
    public List<Order> getAllOrders(){
        return orderService.getAllOrders();
    }


    @GetMapping("/orders/user/{id}")
    public List<Order> getOrdersByUser(@PathVariable long id){
        return orderService.getOrdersByUser(id);
    }

    @GetMapping("/orders/{id}")
    public Order getOrderById(@PathVariable long id){



        return orderService.getOrderById(id);
    }

    @DeleteMapping("/orders/{id}")
    public void deleteOrderById(@PathVariable long id){
        orderService.deleteOrderById(id);
    }

    @PostMapping("/orders")
    public Order saveOrder(@RequestBody LinkedHashMap<String, Object> body) throws IOException {

      ObjectMapper objectMapper = new ObjectMapper();

       String date = body.get("date").toString();
        Shipping shipping = objectMapper.convertValue(body.get("shipping"), Shipping.class);
        shipping = shippingService.saveShipping(shipping);
        String user_id = body.get("userID").toString();

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(body.get("productIDs"));

        List<String> ids = Arrays.asList(objectMapper.readValue(json, String[].class));

        Order order = new Order(date, ids, shipping, user_id);
        order.setShipping_id(shipping.getShipping_id());
        Order newOrder = orderService.saveOrder(order);
        return newOrder;
    }

    @PutMapping("/orders/{id}")
    public Order updateOrder(@PathVariable long id,  @RequestBody  Order newOrder){
        newOrder.setOrder_id(id);
        return orderService.saveOrder(newOrder);
    }


    /* ==================================== Shipping ==================================== */

    @GetMapping("/shippings")
    public List<Shipping> getAllShippings(){
        return shippingService.getAllShippings();
    }

    @GetMapping("/shippings/{id}")
    public Shipping getShippingById(@PathVariable long id){
        return shippingService.getShippingById(id);
    }

    @PostMapping("/shippings")
    public Shipping saveShipping( @RequestBody  Shipping newShipping){
        return shippingService.saveShipping(newShipping);
    }

    @PutMapping("/shippings/{id}")
    public Shipping updateShipping(@PathVariable long id,  @RequestBody  Shipping newShipping){
        newShipping.setShipping_id(id);
        return shippingService.saveShipping(newShipping);
    }

    @DeleteMapping("/shippings/{id}")
    public void deleteShippingById(@PathVariable long id){
        shippingService.deleteShippingById(id);
    }

    @DeleteMapping("/shippings")
    public void deleteShippings(){
        shippingService.deleteAllShippings();
    }


}
