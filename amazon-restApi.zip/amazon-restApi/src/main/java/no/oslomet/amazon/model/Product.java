package no.oslomet.amazon.model;




import lombok.Data;

import javax.persistence.*;
import java.util.List;


@Data
public class Product {
    private long id;
    private String name;
    private String description;
    private long quantity;
    private long likes;
    @ElementCollection
    private List<Long> stars;
    private String picture;
    private long merchant;
    private String category;
}