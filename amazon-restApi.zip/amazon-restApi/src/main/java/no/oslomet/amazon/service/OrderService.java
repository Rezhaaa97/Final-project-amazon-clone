package no.oslomet.amazon.service;

import no.oslomet.amazon.model.Order;
import no.oslomet.amazon.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    public List<Order> getAllOrders(){
        return orderRepository.findAll();
    }

    public Order getOrderById(long id){
        return orderRepository.findById(id).get();
    }

    public Order saveOrder(Order order){
        return orderRepository.save(order);
    }

    public void deleteOrderById(long id){
        orderRepository.deleteById(id);
    }

    public void deleteAllOrders(){
        orderRepository.deleteAll();
    }

    public List<Order> getOrdersByUser(long id){

        List<Order> results = new ArrayList<>();
        for(Order order : orderRepository.findAll()){
            if(order.getUser_id() != null){

                if(Long.parseLong(order.getUser_id() )== id ){
                    results.add(order);
                }
            }
        }


        return results;
    }
}
