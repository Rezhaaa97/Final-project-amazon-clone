package no.oslomet.amazon.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@ToString
@Data
public class Shipping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long shipping_id;
    private String firstName;
    private String lastName;
    private String address;

    @Transient
    private User user;

    @OneToMany(mappedBy="shipping", cascade = CascadeType.ALL)
    private List<Order> orders;


    public Shipping(){

    }

    public Shipping(String firstName, String lastName, String address, User user, List<Order> orders) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.user = user;

    }

}
