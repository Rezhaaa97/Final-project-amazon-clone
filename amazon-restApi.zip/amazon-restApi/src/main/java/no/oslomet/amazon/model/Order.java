package no.oslomet.amazon.model;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

//@Table(name="orders")
@Data
@ToString
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long order_id;
    private String date;
    @ElementCollection(targetClass=String.class)
    private List<String> productIDs;
    @ManyToOne
@JsonIgnore
    private Shipping shipping;
    private  String  user_id;
    private long shipping_id;

    public Order(){

    }

    public Order(String date, List<String> productIDs, Shipping shipping, String user_id) {
        this.date = date;
        this.productIDs = productIDs;
        this.shipping = shipping;
        this.user_id = user_id;
    }




}
