package no.oslomet.product.controller;

import no.oslomet.product.model.Product;
import no.oslomet.product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@org.springframework.web.bind.annotation.RestController
@CrossOrigin
public class RestController {

    public static String uploadDirectory = System.getProperty("user.dir")+"/frontend-client-angular/src/assets";
    public long indice = 0;


    @Autowired
    ProductService productService;

    @GetMapping("/")
    public String home() {
        return "This is the product rest Controll";
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/products/{id}")
    public Product getProductById(@PathVariable long id) {
        return productService.getProductById(id);
    }

    @DeleteMapping("/products/{id}")
    public void deleteProductById(@PathVariable long id) {
        productService.deleteProductById(id);
    }

    @DeleteMapping("/products")
    public void deleteAllProducts() {
        productService.deleteAllProducts();
    }


    @RequestMapping(value="/products",
            method=RequestMethod.POST,
            consumes= MediaType.MULTIPART_FORM_DATA_VALUE)
    public Product saveProductById(@RequestParam("file") MultipartFile file,
                                   Product newProduct) {

        StringBuilder fileName = new StringBuilder();
        Path fileNameAndPath = Paths.get(uploadDirectory, indice+file.getOriginalFilename());
        fileName.append(file.getOriginalFilename());

        try {
            Files.write(fileNameAndPath, file.getBytes());

        } catch (IOException e) {
            e.printStackTrace();
        }

        newProduct.setImage(""+indice+fileName); //fileNameAndPath

        return productService.saveProduct(newProduct);
    }




    @PutMapping("/products/{id}")
    public Product updateProduct(@PathVariable long id,  @RequestBody  Product newProduct){
        newProduct.setId(id);
        return productService.saveProduct(newProduct);
    }

    @GetMapping("/rate/{id1}/{id2}/{id3}")
    public Product rate(@PathVariable("id1") String product_id,
                     @PathVariable("id2") String user_id,
                     @PathVariable("id3") String numberOfRates

    ){

        Product product = productService.getProductById(Long.parseLong(product_id));
        product.getStars().put(user_id, numberOfRates);
        return productService.saveProduct(product);

    }


}
