package no.oslomet.product;

import no.oslomet.product.model.Product;
import no.oslomet.product.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import javax.persistence.ElementCollection;
import java.util.List;

@SpringBootApplication
public class ProductApplication implements CommandLineRunner {

    @Autowired
    ProductRepository productRepository;

    public static void main(String[] args) {
        SpringApplication.run(ProductApplication.class, args);
    }

    @Bean
    WebMvcConfigurer configurer () {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addResourceHandlers (ResourceHandlerRegistry registry) {
                registry.addResourceHandler("/images/**").
                        addResourceLocations("classpath:/images/");
            }
        };
    }

    @Override
    public void run(String... args) throws Exception {
        Product p1 = new Product("Nike air max","new collection of shoes",4,"shoes","http://localhost:9090/images/uploadsHei.png",1);
        //Product p2 = new Product("Addidas","new collection of shoes",4,"uploads/Bilde1.png","shoes",1);
        //Product p3 = new Product("Puma","Soccer shoes",4,"uploads/Bilde1.png","shoes",1);
        //
        //Product p4 = new Product("Shirt polo","Polo by ralphlauren",4,"uploads/Bilde1.png","clothes",1);



        productRepository.save(p1);
        //productRepository.save(p2);
        //productRepository.save(p3);
        //productRepository.save(p4);





    }


}
