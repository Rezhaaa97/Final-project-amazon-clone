package no.oslomet.product.model;


import lombok.Data;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Entity
@Data
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String name;
    private String description;
    private long quantity;

    private HashMap<String, String> stars = new HashMap<>();
    private String image;
    private long merchant_id;
    private String category;
    private double price;




    public Product(String name,String description, long quantity,double price , String category,long merchant_id) {
        this.name = name;
        this.description = description;
        this.quantity = quantity;
        this.category = category;
        this.merchant_id =merchant_id;
        this.price = price;

    }

    public Product(String name,String description, long quantity, String category, String image, long merchant_id) {
        this.name = name;
        this.description = description;
        this.quantity = quantity;
        this.category = category;
        this.image = image;
        this.merchant_id =merchant_id;

    }

    public Product() {
    }
}
