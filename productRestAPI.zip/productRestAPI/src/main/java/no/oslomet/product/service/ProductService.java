package no.oslomet.product.service;


import no.oslomet.product.model.Product;
import no.oslomet.product.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> getAllProducts(){
        return productRepository.findAll();
    }
    public Product getProductById(long id){
        return productRepository.findById(id).get();
    }

    public Product saveProduct(Product product){
        return productRepository.save(product);
    }

    public void deleteProductById(long id){
        productRepository.deleteById(id);
    }

    public void deleteAllProducts(){
        productRepository.deleteAll();
    }

    public boolean saveImage(MultipartFile file, String path) {
        boolean saved = false;
        byte[] bytes = new byte[0];
        try {
            bytes = file.getBytes();

            Files.write(Paths.get(path), bytes);
            saved = true;
        } catch (IOException e) {
            e.printStackTrace();

        }
        return saved;
    }


}
